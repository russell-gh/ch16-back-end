//not good but will do for now
const salt = `ch16-back-end`;

module.export = { salt };
